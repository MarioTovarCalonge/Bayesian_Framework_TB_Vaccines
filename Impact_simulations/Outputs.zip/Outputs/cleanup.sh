#!/bin/bash

country=$1

cd $1/
rm Output_object_1.txt
rm Output_object_2.txt
cd ../

for n in {001..500};
do
    echo $1/Iter/$1_$(printf "%03d" $n)
    cd $1/Iter/$1_$(printf "%03d" $n)
    rm Output_object_1.txt
    rm Output_object_2.txt
    rm Output_object_1_0.txt
    rm Output_object_1_1.txt
    rm Output_object_1_2.txt
    rm Output_object_2_0.txt
    rm Output_object_2_1.txt
    rm Output_object_2_2.txt
    cd ../../../
    #echo $n
done
 

