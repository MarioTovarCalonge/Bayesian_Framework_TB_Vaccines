#!/bin/bash

country=$1

for n in {001..004};
do
    echo $1/Iter/$1_$(printf "%03d" $n)
    cd $1/Iter/$1_$(printf "%03d" $n)
    rm Output_object_1.txt
    rm Output_object_2.txt
    cd ../../../
    #echo $n
done
 

